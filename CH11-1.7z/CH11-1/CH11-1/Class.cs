﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CH11_1
{
    internal class Class
    {  
        public static int Cube(int number)
        {
            return number * number;
        }

        // Cube 方法的過載：處理 double
        public static double Cube(double number)
        {
            return number * number;
        }

        public static int MinElement(int a, int b, int c)
        {
            return Math.Min(a, Math.Min(b, c));
        }

        public static int MinElement(int a, int b, int c, int d)
        {
            return Math.Min(a, Math.Min(b, Math.Min(c, d)));
        }

    }
}
