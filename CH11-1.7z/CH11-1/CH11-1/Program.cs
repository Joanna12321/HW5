﻿namespace CH11_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            / 測試 Cube 方法
        Console.WriteLine("Square of 4 (int): " + Cube(4));          // 16
            Console.WriteLine("Square of 3.5 (double): " + Cube(3.5));   // 12.25

            // 測試 MinElement 方法
            Console.WriteLine("Min of (7, 3, 9): " + MinElement(7, 3, 9));              // 3
            Console.WriteLine("Min of (12, 5, 8, 2): " + MinElement(12, 5, 8, 2));      // 2
        }
    }
}
