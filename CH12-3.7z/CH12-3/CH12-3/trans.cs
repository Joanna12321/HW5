﻿using System;
using System.Collections.Generic;


namespace CH12_3
{
    internal class trans
    {
        
        public delegate double ConvertToInches(double value);
      
        public static double FeetToInches(double feet)
        {
            return feet * 12;
        }
      
        public static double YardsToInches(double yards)
        {
            return yards * 3 * 12;
        }

    }
}
