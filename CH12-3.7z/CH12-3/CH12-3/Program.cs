﻿using static CH12_3.trans;

namespace CH12_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("輸入長度值：");
            double input = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("英尺轉英吋,輸入1");
            Console.WriteLine("英瑪轉英吋,輸入2");
            string option = Console.ReadLine();

            ConvertToInches converter;
   
            if (option == "1")
            {
                converter = new ConvertToInches(FeetToInches);
            }
            else if (option == "2")
            {
                converter = new ConvertToInches(YardsToInches);
            }
            else
            {
                Console.WriteLine("請選擇1或2");
                return;
            }

            double inches = converter(input);
            Console.WriteLine($"{inches} 英吋");
        }
    }
    
}
