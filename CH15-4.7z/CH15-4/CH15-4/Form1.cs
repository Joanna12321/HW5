namespace CH15_4
{
    public partial class Form1 : Form
    {
        private string filePath = "listfile.txt";

        public Form1()
        {
            InitializeComponent();

            if (!File.Exists(filePath))
            {
                File.Create(filePath).Close();
            }
        }

        private void btn1_Click_1(object sender, EventArgs e)
        {
            using (StreamWriter sw = File.AppendText(filePath))
            {
                sw.WriteLine();
                sw.WriteLine("[���|�w]");
            }
            MessageBox.Show("�s�W���|�w");
        }

        private void btn2_Click_1(object sender, EventArgs e)
        {
            using (StreamWriter sw = File.AppendText(filePath))
            {
                sw.WriteLine("[�p�s�k]");
                sw.WriteLine("[�����R]");
            }
            MessageBox.Show("�s�W�p�s�k�M�����R");
        }

        private void btn3_Click_1(object sender, EventArgs e)
        {
            using (StreamReader sr = new StreamReader(filePath))
            {
                char[] buffer = new char[10];
                sr.Read(buffer, 0, 10);
                string result = new string(buffer);
                MessageBox.Show("�e10�Ӧr�G" + result);
            }
        }

        private void btn4_Click_1(object sender, EventArgs e)
        {
            string[] line_3 = File.ReadAllLines(filePath);        
             MessageBox.Show("��3�C�G" + line_3[2]);
        }
    }
}