﻿namespace CH15_4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn1 = new Button();
            btn2 = new Button();
            btn3 = new Button();
            btn4 = new Button();
            SuspendLayout();
            // 
            // btn1
            // 
            btn1.BackColor = SystemColors.ControlDarkDark;
            btn1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 136);
            btn1.ForeColor = SystemColors.ButtonHighlight;
            btn1.Location = new Point(46, 117);
            btn1.Name = "btn1";
            btn1.Size = new Size(140, 58);
            btn1.TabIndex = 0;
            btn1.Text = "step 1";
            btn1.UseVisualStyleBackColor = false;
            btn1.Click += btn1_Click_1;
            // 
            // btn2
            // 
            btn2.BackColor = SystemColors.ControlDarkDark;
            btn2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 136);
            btn2.ForeColor = SystemColors.ButtonHighlight;
            btn2.Location = new Point(212, 117);
            btn2.Name = "btn2";
            btn2.Size = new Size(140, 58);
            btn2.TabIndex = 1;
            btn2.Text = "step 2";
            btn2.UseVisualStyleBackColor = false;
            btn2.Click += btn2_Click_1;
            // 
            // btn3
            // 
            btn3.BackColor = SystemColors.ControlDarkDark;
            btn3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 136);
            btn3.ForeColor = SystemColors.ButtonHighlight;
            btn3.Location = new Point(391, 117);
            btn3.Name = "btn3";
            btn3.Size = new Size(140, 58);
            btn3.TabIndex = 2;
            btn3.Text = "step 3";
            btn3.UseVisualStyleBackColor = false;
            btn3.Click += btn3_Click_1;
            // 
            // btn4
            // 
            btn4.BackColor = SystemColors.ControlDarkDark;
            btn4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 136);
            btn4.ForeColor = SystemColors.ButtonHighlight;
            btn4.Location = new Point(570, 117);
            btn4.Name = "btn4";
            btn4.Size = new Size(140, 58);
            btn4.TabIndex = 3;
            btn4.Text = "step 4";
            btn4.UseVisualStyleBackColor = false;
            btn4.Click += btn4_Click_1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 249);
            Controls.Add(btn4);
            Controls.Add(btn3);
            Controls.Add(btn2);
            Controls.Add(btn1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btn1;
        private Button btn2;
        private Button btn3;
        private Button btn4;
    }
}
