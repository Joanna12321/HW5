namespace CH13_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label1.MouseDown += label1_MouseDown;
        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                label1.BackColor = Color.Yellow;
            }

            else if (e.Button == MouseButtons.Right)
            {
                label1.BackColor = Color.Green;
            }          
        }

    }
}
