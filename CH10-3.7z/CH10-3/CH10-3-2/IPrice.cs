﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CH10_3_2
{
    interface IPrice
    {
         double GetPrice();
    }

    class Car : IPrice
    {
        public double Price;
        public string Name;
        public double GetPrice()
        {
             return GetPrice();
        }
        public string GetName()
        {
            return Name;
        }
        
    }
}
