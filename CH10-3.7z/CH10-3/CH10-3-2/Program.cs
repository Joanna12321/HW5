﻿namespace CH10_3_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
           namespace="XXX"
           console.writeline(Name "價錢為: " IPrice)
        }
    }
}
